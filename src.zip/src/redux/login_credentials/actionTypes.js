export const LOGIN_SUCESS='LOGIN_SUCESS';
export const LOGIN_FAILURE='Login_FAILURE';

export const PROCESS_MORE='PROCESS_MORE';

